# Changelogs

## 8/18/2023
- Added a return path in rvc_convert
- Added mps for Mac for device configuration (untested as I don't have a Mac)

