from setuptools import setup, find_packages

setup(
    name='rvc_tts_pipe',
    version='0.1',
    description='tts-pipeline',
    author='Jarod Mica',
    packages=find_packages(),
)